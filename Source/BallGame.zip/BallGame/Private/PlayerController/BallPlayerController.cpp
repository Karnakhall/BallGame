// Fill out your copyright notice in the Description page of Project Settings.


#include "PlayerController/BallPlayerController.h"

#include "Camera/CameraActor.h"
#include "Characters/BallPlayer.h"
#include "Kismet/GameplayStatics.h"

void ABallPlayerController::BeginPlay()
{
	Super::BeginPlay();
	bShowMouseCursor = true;

	ControlledBall = Cast<ABallPlayer>(GetPawn());

	ACameraActor* MainCamera = Cast<ACameraActor>(UGameplayStatics::GetActorOfClass(GetWorld(), ACameraActor::StaticClass()));
	if (MainCamera)
	{
		SetViewTarget(MainCamera);
	}
}

void ABallPlayerController::SetupInputComponent()
{
	Super::SetupInputComponent();

	InputComponent->BindAction(FName("Move"), IE_Pressed, this, &ABallPlayerController::OnMoveKeyPressed);
	InputComponent->BindAction(FName("Move"), IE_Released, this, &ABallPlayerController::OnMoveKeyReleased);
	
}

void ABallPlayerController::OnMoveKeyPressed() { bIsMoveKeyPressed = true; }
void ABallPlayerController::OnMoveKeyReleased() { bIsMoveKeyPressed = false; }

void ABallPlayerController::PlayerTick(float DeltaTime)
{
	Super::PlayerTick(DeltaTime);
	if (bIsMoveKeyPressed && ControlledBall)
	{
		FVector MouseLocation, MouseDirection;
		DeprojectMousePositionToWorld(MouseLocation, MouseDirection);

		FVector GroundPlaneOrigin(0, 0, 0);
		FVector GroundPlaneNormal(0, 0, 1);
		FVector TargetLocation = FMath::LinePlaneIntersection(MouseLocation, MouseLocation + MouseDirection * 10000.f, GroundPlaneOrigin, GroundPlaneNormal);

		ControlledBall->SetMoveTarget(TargetLocation);
	} 
}
